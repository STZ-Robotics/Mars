package com.stzteam.mars.generated;

// AUTO-GENERATED FILE DO NOT EDIT

public final class MarsConstants {
    public static final String MARS_VERSION = "1.6.2";
}
